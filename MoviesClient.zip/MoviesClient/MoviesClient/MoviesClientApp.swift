//
//  MoviesClientApp.swift
//  MoviesClient
//
//  Created by Mohammad Azam on 1/31/25.
//

import SwiftUI

@main
struct MoviesClientApp: App {
    var body: some Scene {
        WindowGroup {
            MovieListScreen() 
        }
    }
}
