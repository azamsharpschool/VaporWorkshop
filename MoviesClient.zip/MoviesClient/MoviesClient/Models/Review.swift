//
//  Review.swift
//  MoviesClient
//
//  Created by Mohammad Azam on 2/1/25.
//

import Foundation

struct Review: Codable, Identifiable {
    var id: UUID?
    let subject: String
    let description: String
    let movieId: UUID 
}
