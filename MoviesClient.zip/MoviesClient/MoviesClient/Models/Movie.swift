//
//  Movie.swift
//  MoviesClient
//
//  Created by Mohammad Azam on 1/31/25.
//

import Foundation

struct Movie: Codable, Identifiable {
    var id: UUID?
    let name: String
}
