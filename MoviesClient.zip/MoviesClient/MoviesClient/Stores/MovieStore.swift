//
//  MovieStore.swift
//  MoviesClient
//
//  Created by Mohammad Azam on 1/31/25.
//

import Foundation
import Observation

enum Endpoint {
    case movies
    case addMovie
    case reviewsByMovie(Movie)
    case addReviewForMovieId(UUID)
    
    var url: URL {
        switch self {
            case .movies:
                return URL(string: "http://127.0.0.1:8080/movies")!
            case .addMovie:
                return URL(string: "http://127.0.0.1:8080/movies")!
            case .reviewsByMovie(let movie):
                return URL(string: "http://127.0.0.1:8080/movies/\(movie.id!)/reviews")!
            case .addReviewForMovieId(let movieId):
                return URL(string: "http://127.0.0.1:8080/movies/\(movieId)/reviews")!
        }
    }
}

@Observable
class MovieStore {
    
    // use a protocol for mocking unmanaged dependencies
    let httpClient: HTTPClient
    var movies: [Movie] = []
    
    init(httpClient: HTTPClient) {
        self.httpClient = httpClient
    }
    
    func addReview(review: Review) async throws -> Review {
        let body = try JSONEncoder().encode(review)
        let resource = Resource(url: Endpoint.addReviewForMovieId(review.movieId).url, method: .post(body), modelType: Review.self)
        return try await httpClient.load(resource)
    }
    
    func loadReviewsBy(movie: Movie) async throws -> [Review] {
        let resource = Resource(url: Endpoint.reviewsByMovie(movie).url, modelType: [Review].self)
        return try await httpClient.load(resource)
    }
    
    func addMovie(movie: Movie) async throws {
        let body = try JSONEncoder().encode(movie)
        let resource = Resource(url: Endpoint.addMovie.url, method: .post(body), modelType: Movie.self)
        let newMovie = try await httpClient.load(resource)
        movies.append(newMovie)
    }
    
    func loadMovies() async throws {
        let resource = Resource(url: Endpoint.movies.url, modelType: [Movie].self)
        movies = try await httpClient.load(resource)
    }
    
}

