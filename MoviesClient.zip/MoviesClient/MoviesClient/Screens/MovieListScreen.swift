import SwiftUI

struct MovieListScreen: View {
    
    @Environment(MovieStore.self) private var movieStore
    @State private var isLoading = false
    @State private var errorMessage: String?
    @State private var isPresented: Bool = false
    
    var body: some View {
        List(movieStore.movies) { movie in
            NavigationLink {
                MovieDetailScreen(movie: movie)
            } label: {
                Text(movie.name)
            }
        }
        .overlay(alignment: .center, content: {
            if isLoading {
                ProgressView("Loading movies...")
            } else if let errorMessage {
                Text(errorMessage)
            }
        })
        .navigationTitle("Movies")
        .toolbar(content: {
            ToolbarItem(placement: .topBarTrailing) {
                Button("New Movie") {
                    isPresented = true
                }
            }
        })
        .sheet(isPresented: $isPresented, content: {
            AddMovieScreen() 
        })
        .task {
            await loadMovies()
        }
    }
    
    private func loadMovies() async {
        
        isLoading = true
        errorMessage = nil
        
        do {
            try await movieStore.loadMovies()
        } catch {
            errorMessage = error.localizedDescription
        }
        
        isLoading = false
    }
}

#Preview {
    NavigationStack {
        MovieListScreen()
    }.environment(MovieStore(httpClient: HTTPClient()))
}
