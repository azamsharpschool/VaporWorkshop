//
//  MovieDetailScreen.swift
//  MoviesClient
//
//  Created by Mohammad Azam on 2/1/25.
//

import SwiftUI

struct MovieDetailScreen: View {
    
    let movie: Movie
    
    @Environment(MovieStore.self) private var movieStore
    
    @State private var subject: String = ""
    @State private var description: String = ""
    
    @State private var reviews: [Review] = []
    
    var body: some View {
        Form {
            TextField("Subject", text: $subject)
            TextField("Description", text: $description)
            Button("Save") {
                let review = Review(subject: subject, description: description, movieId: movie.id!)
                Task {
                    do {
                        let newReview = try await movieStore.addReview(review: review)
                        reviews.append(newReview)
                    } catch {
                        print(error.localizedDescription)
                    }
                }
            }
            
            List(reviews) { review in
                Text(review.subject)
            }
            
        }.navigationTitle(movie.name)
            .task {
                do {
                    reviews = try await movieStore.loadReviewsBy(movie: movie)
                } catch {
                    print(error.localizedDescription)
                }
            }
    }
}

#Preview {
    MovieDetailScreen(movie: Movie(id: UUID(uuidString: "8376a1f7-d3bb-4238-84ae-2a6d93c5867c"), name: "Spider man"))
        .environment(MovieStore(httpClient: HTTPClient()))
}
