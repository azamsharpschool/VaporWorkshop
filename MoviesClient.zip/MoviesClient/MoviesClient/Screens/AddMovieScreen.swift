//
//  AddMovieScreen.swift
//  MoviesClient
//
//  Created by Mohammad Azam on 1/31/25.
//

import SwiftUI

struct AddMovieScreen: View {
    
    @Environment(MovieStore.self) private var movieStore
    @Environment(\.dismiss) private var dismiss
    @State private var name: String = ""
    
    private func saveMovie() async {
        let movie = Movie(name: name)
        do {
            try await movieStore.addMovie(movie: movie)
            dismiss() 
        } catch {
            print(error.localizedDescription)
        }
    }
    
    var body: some View {
        Form {
            TextField("Name", text: $name)
            Button("Save") {
                Task {
                    await saveMovie()
                }
            }
        }.navigationTitle("Add Movie")
    }
}

#Preview {
    NavigationStack {
        AddMovieScreen()
    }.environment(MovieStore(httpClient: HTTPClient()))
}
