//
//  File.swift
//  HelloVapor
//
//  Created by Mohammad Azam on 8/19/25.
//

import Foundation
import Vapor
import Fluent

struct MoviesController: RouteCollection {
    
    let movieStore = MovieStore()
    
    func boot(routes: any RoutesBuilder) throws {
        
        let movies = routes.grouped("movies")
        movies.get(use: index)
        movies.post(use: create)
        
        /*
        movies.group(":genre") { movie in
            movie.get(use: moviesByGenre)
        } */
        
        movies.group(":id") { movie in
            movie.delete(use: delete)
        }
        
    }
    
    private func delete(req: Request) async throws -> Movie {
        
        // get the id
        guard let movieId = req.parameters.get("id", as: UUID.self) else {
            throw Abort(.badRequest, reason: "Invalid or missing id.")
        }
        
        guard let movie = try await Movie.find(movieId, on: req.db) else {
            throw Abort(.notFound, reason: "Movie not found.")
        }
        
        try await movie.delete(on: req.db)
        return movie
    }
    
    private func index(req: Request) async throws -> [Movie] {
        
        let moviesQuery = try req.query.decode(MoviesQuery.self)
        
        switch moviesQuery.sort {
        case .asc:
            return try await Movie.query(on: req.db)
                .sort(\.$name, .ascending)
                .all()
        case .desc:
            return try await Movie.query(on: req.db)
                .sort((\.$name), .descending)
                .all()
        case .none:
            return try await Movie.query(on: req.db)
                .all()
        }
    }
    
    private func update(req: Request) async throws -> Movie {
        
        guard let movieId = req.parameters.get("id", as: UUID.self) else {
            throw Abort(.badRequest, reason: "Invalid or missing movie Id")
        }
        
        // get the persisted movie
        guard let existingMovie = try await Movie.find(movieId, on: req.db) else {
            throw Abort(.notFound, reason: "Movie not found.")
        }
        
        // get the updated movie
        let updatedMovie = try req.content.decode(Movie.self)
        
        // update the fields
        existingMovie.name = updatedMovie.name
        
        // persist
        try await existingMovie.update(on: req.db)
        
        return existingMovie
    }
    
    private func create(req: Request) async throws -> Movie {
        
        try Movie.validate(content: req)
        
        let movie = try req.content.decode(Movie.self)
        try await movie.save(on: req.db)
        return movie
    }
    
    private func moviesByGenre(req: Request) async throws -> [Movie] {
        
        let genre = try req.parameters.require("genre")
        return try await Movie.query(on: req.db)
            .filter(\.$genre, .equal, genre)
            .all()
    }
    
}
