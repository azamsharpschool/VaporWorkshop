//
//  CreateMoviesTableMigration.swift
//  HelloVapor
//
//  Created by Mohammad Azam on 8/20/25.
//

import Foundation
import Fluent

struct CreateMoviesTableMigration: AsyncMigration {
    
    func prepare(on database: any Database) async throws {
        
        try await database.schema("movies")
            .id()
            .field("name", .string, .required)
            .field("genre", .string, .required)
            .field("rating", .double, .required)
            .field("year", .int, .required)
            .create()
    }
    
    func revert(on database: any Database) async throws {
        try await database.schema("movies")
            .delete()
    }
    
}
