//
//  File.swift
//  HelloVapor
//
//  Created by Mohammad Azam on 8/20/25.
//

import Foundation
import Vapor
import Fluent

final class Movie: Model, Content, @unchecked Sendable {
    
    static let schema: String = "movies"
    
    @ID(key: .id)
    var id: UUID?
    
    @Field(key: "name")
    var name: String
    
    @Field(key: "genre")
    var genre: String
    
    @Field(key: "rating")
    var rating: Double
    
    @Field(key: "year")
    var year: Int
    
    @Children(for: \.$movie)
    var reviews: [Review]
    
    init() { }
    
    init(id: UUID? = nil, name: String, genre: String, rating: Double, year: Int) {
        self.id = id
        self.name = name
        self.genre = genre
        self.rating = rating
        self.year = year
    }
    
}

extension Movie: Validatable {
    static func validations(_ validations: inout Validations) {
        validations.add("name", as: String.self, is: .count(1...), required: true, customFailureDescription: "Name is not provided.")
    }
}

