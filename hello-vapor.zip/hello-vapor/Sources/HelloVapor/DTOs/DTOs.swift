//
//  DTOs.swift
//  HelloVapor
//
//  Created by Mohammad Azam on 8/20/25.
//

import Vapor 

struct CreateReview: Content {
    let subject: String
    let description: String
}

struct ReviewResponse: Content {
    let id: UUID
    let subject: String
    let description: String
}
