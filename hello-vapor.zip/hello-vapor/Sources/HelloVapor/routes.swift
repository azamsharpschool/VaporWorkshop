import Vapor

func routes(_ app: Application) throws {
    
    app.routes.caseInsensitive = true
    try app.register(collection: MoviesController())
    try app.register(collection: ReviewsController())
}
