//
//  MovieStore.swift
//  HelloVapor
//
//  Created by Mohammad Azam on 8/19/25.
//

import Foundation
import Vapor 

enum SortOrder: Content {
    case asc
    case desc
}

struct MoviesQuery: Content {
    var sort: SortOrder?
}

actor MovieStore {
    
    private var movies: [Movie] = [
        Movie(id: UUID(), name: "Inception", genre: "Sci-Fi", rating: 8.8, year: 2010),
        Movie(id: UUID(), name: "The Dark Knight", genre: "Action", rating: 9.0, year: 2008),
        Movie(id: UUID(), name: "Interstellar", genre: "Sci-Fi", rating: 8.6, year: 2014),
        Movie(id: UUID(), name: "Parasite", genre: "Thriller", rating: 8.6, year: 2019),
        Movie(id: UUID(), name: "The Godfather", genre: "Crime", rating: 9.2, year: 1972)
    ]

    func getAll() async -> [Movie] {
        movies
    }
    
    func createMovie(_ movie: Movie) async -> Movie {
        let newMovie = movie
        newMovie.id = UUID()
        movies.append(newMovie)
        return newMovie
    }
    
    func filterBy(_ genre: String) async -> [Movie] {
        movies.filter { $0.genre == genre }
    }
    
    func sortBy(_ sortOrder: SortOrder) async -> [Movie] {
        
        switch sortOrder {
        case .asc:
            movies.sorted { lhs, rhs in
                lhs.name > rhs.name
            }
        case .desc:
            movies.sorted { lhs, rhs in
                lhs.name < rhs.name
            }
        }
        
    }
}
