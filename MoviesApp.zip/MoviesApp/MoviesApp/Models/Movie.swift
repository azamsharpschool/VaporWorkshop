//
//  Movie.swift
//  MoviesApp
//
//  Created by Mohammad Azam on 8/20/25.
//

import Foundation 

struct Movie: Codable, Identifiable {
    var id: UUID?
    let name: String
    let genre: String
    let rating: Double
    let year: Int
}
