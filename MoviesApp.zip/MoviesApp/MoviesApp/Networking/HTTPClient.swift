//
//  HTTPClient.swift
//  MoviesApp
//
//  Created by Mohammad Azam on 8/20/25.
//

import Foundation

struct HTTPClient {
    
    func fetchMovies() async throws -> [Movie] {
        let url = URL(string: "http://127.0.0.1:8080/movies")!
        let (data, _) = try await URLSession.shared.data(from: url)
        return try JSONDecoder().decode([Movie].self, from: data)
    }
    
    func addMovie(_ movie: Movie) async throws -> Movie {
        
        let url = URL(string: "http://127.0.0.1:8080/movies")!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue( "application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try JSONEncoder().encode(movie)
        
        let (data, _) = try await URLSession.shared.data(for: request)
        let movie = try JSONDecoder().decode(Movie.self, from: data)
        return movie
    }
    
}
