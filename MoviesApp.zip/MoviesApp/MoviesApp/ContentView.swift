//
//  ContentView.swift
//  MoviesApp
//
//  Created by Mohammad Azam on 8/20/25.
//

import SwiftUI

struct AddMovieScreen: View {
    
    @Environment(MovieStore.self) private var movieStore
    
    @State private var name: String = ""
    @State private var genre: String = ""
    @State private var rating: Double = 5.0
    @State private var year: Int?
    
    var body: some View {
        NavigationStack {
            Form {
                Section(header: Text("Movie Info")) {
                    TextField("Name", text: $name)
                    TextField("Genre", text: $genre)
                    
                    HStack {
                        Text("Rating")
                        Spacer()
                        Slider(value: $rating, in: 0...10, step: 0.1)
                            .frame(width: 200)
                        Text(String(format: "%.1f", rating))
                            .foregroundColor(.secondary)
                    }
                    
                    TextField("Year", value: $year, format: .number)
                        .keyboardType(.numberPad)
                }
                
                Section {
                    Button("Save Movie") {
                        Task {
                            let movie = Movie(name: name, genre: genre, rating: rating, year: year!)
                            do {
                                try await movieStore.saveMovie(movie)
                            } catch {
                                print(error.localizedDescription)
                            }
                        }
                    }
                }
            }
            .navigationTitle("Add Movie")
        }
    }
}

#Preview("AddMovieScreen") {
    AddMovieScreen()
}

struct ContentView: View {
    
    @Environment(MovieStore.self) private var movieStore
    @State private var isPresented: Bool = false
    
    var body: some View {
        List(movieStore.movies) { movie in
            Text(movie.name)
        }.task {
            do {
                try await movieStore.loadMovies()
            } catch {
                print(error.localizedDescription)
            }
        }
        .toolbar(content: {
            ToolbarItem(placement: .topBarTrailing) {
                Button("Add Movie") {
                    isPresented = true
                }
            }
        })
        .sheet(isPresented: $isPresented, content: {
            AddMovieScreen()
        })
        .navigationTitle("Movies")
        
    }
}

#Preview {
    NavigationStack {
        ContentView()
    }
    .environment(MovieStore(httpClient: HTTPClient()))
}
