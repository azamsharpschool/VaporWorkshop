//
//  MoviesAppApp.swift
//  MoviesApp
//
//  Created by Mohammad Azam on 8/20/25.
//

import SwiftUI

@main
struct MoviesAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
