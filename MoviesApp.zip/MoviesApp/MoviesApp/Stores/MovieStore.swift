//
//  MovieStore.swift
//  MoviesApp
//
//  Created by Mohammad Azam on 8/20/25.
//

import Foundation
import Observation

@MainActor
@Observable
class MovieStore {
    
    var movies: [Movie] = []
    let httpClient: HTTPClient
    
    init(httpClient: HTTPClient) {
        self.httpClient = httpClient
    }
    
    func loadMovies() async throws {
        movies = try await httpClient.fetchMovies()
    }
    
    func saveMovie(_ movie: Movie) async throws {
        let movie = try await httpClient.addMovie(movie)
        movies.append(movie)
    }
    
}
