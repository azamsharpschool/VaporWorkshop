//
//  ReviewController.swift
//  movies-app
//
//  Created by Mohammad Azam on 2/1/25.
//

import Vapor
import Fluent

struct ReviewsController: RouteCollection {
    
    func boot(routes: any RoutesBuilder) throws {
        let reviews = routes.grouped("movies", ":movieId", "reviews")
        reviews.post(use: addReview)
        reviews.get(use: getReviewsForMovie)
    }
    
    @Sendable
    private func addReview(req: Request) async throws -> ReviewResponse {
        
        // Validate and extract the movie ID from the request parameters
        guard let movieId = req.parameters.get("movieId", as: UUID.self) else {
            throw Abort(.badRequest, reason: "Invalid or missing movie ID")
        }
        
        // Fetch the movie to ensure it exists
        guard let movie = try await Movie.find(movieId, on: req.db) else {
            throw Abort(.notFound, reason: "Movie not found")
        }
        
        let createReview = try req.content.decode(CreateReview.self)
        
        let review = Review(subject: createReview.subject, description: createReview.description, movieId: movie.id!)
        
        try await review.save(on: req.db)
        
        return ReviewResponse(id: review.id!, subject: review.subject, description: review.description)
        
    }
    
    @Sendable
    private func getReviewsForMovie(req: Request) async throws -> [ReviewResponse] {
        // Validate and extract the movie ID from the request parameters
        guard let movieId = req.parameters.get("movieId", as: UUID.self) else {
            throw Abort(.badRequest, reason: "Invalid or missing movie ID")
        }
        
        // Fetch all reviews for the movie
        return try await Review.query(on: req.db)
            .filter(\.$movie.$id == movieId)
            .all()
            .map {
                ReviewResponse(id: $0.id!, subject: $0.subject, description: $0.description)
            }
    }
    
}
