//
//  MoviesController.swift
//  movies-app
//
//  Created by Mohammad Azam on 1/31/25.
//

import Foundation
import Vapor
import Fluent

struct MoviesController: RouteCollection {
    
    func boot(routes: any RoutesBuilder) throws {
        
        let movies = routes.grouped("movies")
        movies.get(use: index)
        movies.post(use: create)
        
        movies.group(":id") { movie in
            movie.delete(use: delete)
            movie.put(use: update)
        }
    }
    
    @Sendable
    private func update(req: Request) async throws -> Movie {
        
        guard let movieId = req.parameters.get("id", as: UUID.self) else {
            throw Abort(.badRequest, reason: "Invalid or missing movie Id")
        }
        
        // get the persisted movie
        guard let existingMovie = try await Movie.find(movieId, on: req.db) else {
            throw Abort(.notFound, reason: "Movie not found.")
        }
        
        // get the updated movie 
        let updatedMovie = try req.content.decode(Movie.self)
        
        // update the fields
        existingMovie.name = updatedMovie.name
        
        // persist
        try await existingMovie.update(on: req.db)
        
        return existingMovie
    }
    
    @Sendable
    private func delete(req: Request) async throws -> Movie {
        
        guard let movieId = req.parameters.get("id", as: UUID.self) else {
            throw Abort(.badRequest, reason: "Invalid or missing movie Id")
        }
        
        guard let movie = try await Movie.find(movieId, on: req.db) else {
            throw Abort(.notFound, reason: "Movie not found.")
        }
        
        try await movie.delete(on: req.db)
        
        return movie
        
    }
    
    @Sendable
    private func create(req: Request) async throws -> Movie {
        
        try Movie.validate(content: req)
        
        let movie = try req.content.decode(Movie.self)
        try await movie.save(on: req.db)
        return movie
    }
    
    @Sendable
    private func index(req: Request) async throws -> [Movie] {
        try await Movie.query(on: req.db)
            .all()
    }
    
}

