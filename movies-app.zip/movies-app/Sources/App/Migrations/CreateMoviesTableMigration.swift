//
//  CreateMoviesTableMigration.swift
//  movies-app
//
//  Created by Mohammad Azam on 1/31/25.
//

import Foundation
import Fluent

struct CreateMoviesTableMigration: AsyncMigration {
    
    func prepare(on database: any Database) async throws {
        try await database.schema("movies")
            .id()
            .field("name", .string, .required)
            .create()
    }
    
    func revert(on database: any Database) async throws {
        try await database.schema("movies")
            .delete()
    }
    
}
