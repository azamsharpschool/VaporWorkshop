//
//  DTOs.swift
//  movies-app
//
//  Created by Mohammad Azam on 2/1/25.
//

import Vapor

struct CreateReview: Content {
    let subject: String
    let description: String
}

struct ReviewResponse: Content {
    let id: UUID
    let subject: String
    let description: String
}
