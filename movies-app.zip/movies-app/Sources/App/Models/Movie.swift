//
//  Movie.swift
//  movies-app
//
//  Created by Mohammad Azam on 1/31/25.
//

import Foundation
import Vapor
import Fluent

final class Movie: Model, Content, @unchecked Sendable {
    
    static let schema: String = "movies"
    
    @ID(key: .id)
    var id: UUID?
    
    @Field(key: "name")
    var name: String
    
    @Children(for: \.$movie)
    var reviews: [Review]
    
    init() { }
    
    init(id: UUID? = nil, name: String) {
        self.id = id
        self.name = name
    }
}

extension Movie: Validatable {
    
    static func validations(_ validations: inout Validations) {
        validations.add("name", as: String.self, is: .count(1...), required: true, customFailureDescription: "Name is not provided.")
    }
    
}
