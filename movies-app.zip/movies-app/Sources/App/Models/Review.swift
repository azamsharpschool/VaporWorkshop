//
//  Review.swift
//  movies-app
//
//  Created by Mohammad Azam on 1/31/25.
//

import Foundation
import Vapor
import Fluent

final class Review: Model, Content, @unchecked Sendable {
    
    static let schema: String = "reviews"
    
    @ID(key: .id)
    var id: UUID?
    
    @Field(key: "subject")
    var subject: String
        
    @Field(key: "description")
    var description: String
    
    @Parent(key: "movie_id")
    var movie: Movie
    
    init() { }
    
    init(id: UUID? = nil, subject: String, description: String, movieId: Movie.IDValue) {
        self.id = id
        self.subject = subject
        self.description = description
        self.$movie.id = movieId
    }
    
}

